package com.igap.adpro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdproApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdproApplication.class, args);
	}

}
