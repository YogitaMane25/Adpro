package com.igap.adpro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdproApplicationTests {

	@Test
	void contextLoads() {
	}

}
